using BusTrackSV.Models;
using Data.Repositories;

namespace BusTrackSV.Service;
public class ChoferService
{
    private readonly ChoferRepository _choferRepository;
    private readonly BusRepository _busRepository;
    private readonly UsuarioRepository _usuarioRepository;

    public ChoferService(ChoferRepository choferRepository, BusRepository busRepository, UsuarioRepository usuarioRepository)
    {
        _choferRepository = choferRepository;
        _busRepository = busRepository;
        _usuarioRepository = usuarioRepository;
    }

    public List<Chofer> Get(int userID)
    {
        var choferesIDs = _choferRepository.GetChoferIdByUserID(userID);
        var choferes = new List<Chofer>();

        foreach(var id in choferesIDs)
        {
            var chofer = _choferRepository.GetChoferByID(id);
            if(chofer != null)
            {
                choferes.Add(chofer);
            }
        }

        return choferes;
    }

    public Chofer GetChofer(int userID, int choferID)
    {

                
        var choferes = _choferRepository.GetChoferIdByUserID(userID);        
        if(choferes.Contains(choferID) == false)
        {
            throw new UserInvalidado();
        }

        var chofer = _choferRepository.GetChoferByID(choferID);

        if(chofer == null)
        {
            throw new NullValue();
        }

        return chofer;
    }
    public void AddChofer(int userID, ChoferRegistroDTO nuevoChofer)
    {
        var buses = _busRepository.GetBusesIDByUserID(userID);
        if(userID <= 0)
        {
            throw new UserInvalidado();
        }
        
        if(buses.Contains(nuevoChofer.id_bus) == false)
        {
            throw new UserInvalidado();
        }

       Bus? bus = _busRepository.GetBusById(nuevoChofer.id_bus);

        if(bus == null)
        {
            throw new NullValue();
        }

       if(bus.id_usuario != userID)
       {
            throw new UserInvalidado();
       }

        if(string.IsNullOrEmpty(nuevoChofer.telefono_chofer) || string.IsNullOrEmpty(nuevoChofer.nombre_completo))
        {
            throw new CamposRequeridosException();
        }

        _choferRepository.RegistrarChofer(nuevoChofer);
    }

    public void UpdateChofer(int userID, Chofer chofer)
    {
        var choferes = _choferRepository.GetChoferIdByUserID(userID);
        if(choferes.Contains(chofer.id_chofer) == false)
        {
            throw new UserInvalidado();
        }

        if(string.IsNullOrEmpty(chofer.telefono_chofer) || string.IsNullOrEmpty(chofer.nombre_completo))
        {
            throw new CamposRequeridosException();
        }

        _choferRepository.ActualizarChofer(chofer);
    }
    public BusRutaInfo GetBusRutaInfo(int ChoferUsuarioID)
    {
        if(ChoferUsuarioID <= 0)
            throw new UserInvalidado();

        var busRutaInfo = _choferRepository.GetBusByChoferUserID(ChoferUsuarioID);
        if(busRutaInfo == null)
        {
            throw new NullValue("El chofer no tiene un bus asignado.");
        }        
        return busRutaInfo;
    }
    
    public void DeleteChofer(int userID, int choferID)
    {
        var choferes = _choferRepository.GetChoferIdByUserID(userID);
        if(choferes.Contains(choferID) == false)
        {
            throw new UserInvalidado();
        }

        var id_user = _choferRepository.GetChoferUsuario(choferID);        
        if(id_user != 0)
        {            
            _usuarioRepository.EliminarUsuario(id_user);
        } // no existe usuario de chofer?? xd   
        _choferRepository.EliminarChofer(choferID);        
    }
}